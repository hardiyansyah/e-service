<?php 
$txt = '
<table width="100%">
<tbody><tr>
    <td width="50%">
    </td>
    <td style="font-size:12px;padding:10px 0 10px 4px">
        <table style="border-collapse:collapse;border-spacing:0px" cellspacing="0" cellpadding="0" border="0">
            <tbody><tr>
                <td style="padding:15px">
                    <table border="0" align="center" width="700">
                        <tbody><tr>
                            <td>
                                <table align="left" width="180" border="0">
                                    <tbody>
                                        <tr align="left">
                                            <td>
                                               <a href="http://lipi.wisasi.com" target="_blank"><img src="http://lipi.wisasi.com/logo-lipi.png" alt="LIPI Press" height="80px" border="0">
                                                </a>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                                <table align="right" width="500" style="margin-top:50px;border-collapse:collapse" border="0">
                                    <tbody>
                                        <tr align="right">
                                            <td>
                                                <h1 style="font-size:18px;color:#4c4848;font-weight:bold">
                                                    <span style="color:rgb(76,72,72);font-weight:bold">
                                                        Konfirmasi Kesanggupan Menelaah
                                                    </span>
                                                </h1>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </td>
                        </tr>
                    </tbody></table>
                </td>
            </tr>
            <tr>
                <td style="background-color:rgb(255,255,255);padding:0px 15px 0px 15px">
                    <p style="border-bottom:1px dotted #efebec;width:100%">&nbsp;</p>
                    <p>Dear <strong>'.$namaReviewer.' (Penelaah)</strong>,</p>
                    <p style="margin-bottom:10px;line-height:150%;text-align:justify">
                        Anda baru saja ditugaskan untuk Menelaah naskah :
                    </p>
                    <br>
                    <table width="700" cellspacing="0" cellpadding="5" style="border:1px solid #dee2e3">
                        <tbody>
                        <tr>
                            <td colspan="5" align="right" valign="top" style="font-size:12px;font-family:Arial,Helvetica,sans-serif;border-bottom:1px solid #dee2e3;font-weight:bold;text-align:left"><div align="left">DETAIL NASKAH</strong></div></td>
                        </tr>
                        <tr>
                            <td width="50%" style="font-size:12px;font-family:Arial,Helvetica,sans-serif;background:#dceff5;font-weight:bold;text-align:center">
                                <div align="left">Judul</div>
                            </td>
                            <td width="50%" style="font-size:12px;font-family:Arial,Helvetica,sans-serif;background:#dceff5;font-weight:bold;text-align:center">
                                <div align="left">: '.$judul.'</div>
                            </td>
                        </tr>
                        <tr>
                            <td valign="top" style="font-size:11px;font-family:Arial,Helvetica,sans-serif;border-bottom:1px solid #dee2e3">
                                <div align="left">Uraian Singkat</div>
                            </td>
                            <td valign="top" style="font-size:11px;font-family:Arial,Helvetica,sans-serif;border-bottom:1px solid #dee2e3">
                                <div align="left"><strong>: '.$sinopsis.'</strong></div>
                            </td>
                        </tr>
                        <tr>
                            <td valign="top" style="font-size:11px;font-family:Arial,Helvetica,sans-serif;border-bottom:1px solid #dee2e3">
                                <div align="left">Instansi</div>
                            </td>
                            <td valign="top" style="font-size:11px;font-family:Arial,Helvetica,sans-serif;border-bottom:1px solid #dee2e3">
                                <div align="left"><strong>: '.$instansi.'</strong></div>
                            </td>
                        </tr>
                        <tr>
                            <td valign="top" style="font-size:11px;font-family:Arial,Helvetica,sans-serif;border-bottom:1px solid #dee2e3">
                                <div align="left">Satuan Kerja</div>
                            </td>
                            <td valign="top" style="font-size:11px;font-family:Arial,Helvetica,sans-serif;border-bottom:1px solid #dee2e3">
                                <div align="left"><strong>: '.$satker.'</strong></div>
                            </td>
                        </tr>
                        <tr>
                            <td valign="top" style="font-size:11px;font-family:Arial,Helvetica,sans-serif;border-bottom:1px solid #dee2e3">
                                <div align="left">Jumlah Halaman</div>
                            </td>
                            <td valign="top" style="font-size:11px;font-family:Arial,Helvetica,sans-serif;border-bottom:1px solid #dee2e3">
                                <div align="left"><strong>: '.$hal.'</strong></div>
                            </td>
                        </tr>                       
                        </tbody>
                    </table>
                    <p align="right" style="margin-top:15px">Dikirim pada : '.$dateTime.'</p>
                    <!-- <table width="700" cellspacing="0" cellpadding="5" style="border:1px solid #dee2e3">
                        <tbody>
                        <tr>
                            <td colspan="5" align="right" valign="top" style="font-size:12px;font-family:Arial,Helvetica,sans-serif;border-bottom:1px solid #dee2e3;font-weight:bold;text-align:left"><div align="left">DATA NASKAH</div></td>
                        </tr>
                        <tr>
                            <td width="50%" style="font-size:12px;font-family:Arial,Helvetica,sans-serif;background:#dceff5;font-weight:bold;text-align:center">
                                <div align="left">Judul Naskah</div>
                            </td>
                            <td width="50%" style="font-size:12px;font-family:Arial,Helvetica,sans-serif;background:#dceff5;font-weight:bold;text-align:center">
                                <div align="left">Judul Naskah na</div>
                            </td>
                        </tr>
                        <tr>
                            <td valign="top" style="font-size:11px;font-family:Arial,Helvetica,sans-serif;border-bottom:1px solid #dee2e3">
                                <div align="left">Satuan Kerja</div>
                            </td>
                            <td valign="top" style="font-size:11px;font-family:Arial,Helvetica,sans-serif;border-bottom:1px solid #dee2e3">
                                <div align="left"><strong>Ilmuan</strong></div>
                            </td>
                        </tr>
                        <tr>
                            <td valign="top" style="font-size:11px;font-family:Arial,Helvetica,sans-serif;border-bottom:1px solid #dee2e3">
                                <div align="left">Abstrak</div>
                            </td>
                            <td valign="top" style="font-size:11px;font-family:Arial,Helvetica,sans-serif;border-bottom:1px solid #dee2e3">
                                <div align="left"><strong>5334719</strong></div>
                            </td>
                        </tr>
                        <tr>
                            <td valign="top" style="font-size:11px;font-family:Arial,Helvetica,sans-serif;border-bottom:1px solid #dee2e3">
                                <div align="left">Status</div>
                            </td>
                            <td valign="top" style="font-size:11px;font-family:Arial,Helvetica,sans-serif;border-bottom:1px solid #dee2e3">
                                <div align="left"><strong>Menunggu Nama Penelaah</strong></div>
                            </td>
                        </tr>                        
                        </tbody>
                    </table> -->
                    <style type="text/css">
                    .bersedia{
                    	background-color: #95b75d;;
    					color: #FFFFFF;
					    padding: 14px 20px;
					    border-radius: 7px;
					    border-color: #95b75d;
					    text-decoration: none;
                    }
                    .tdk-bersedia{
                    	background-color: red;
    					color: #FFFFFF;
					    padding: 14px 20px;
					    border-radius: 7px;
					    border-color: red;
					    text-decoration: none;
                    }
                    </style>
					<p style="margin:20px 0pt 0pt;line-height:150%;text-align:justify;"> Klik <a href="'.$site.'media.php?hal=reviewer-detail-naskah&id='.$id_naskah.'" ><strong> Disini </strong></a>untuk melihat detail naskah dan Tentukan Jawaban Anda Bersedia Atau Tidak Untuk Menelaah Naskah ini</p>
                    <!--<table border="0" align="center" style="padding-top:25px">
                        <tbody>
                        	<tr>
	                            <td width="150" height="auto">
	                                <a href="#" class="bersedia">Bersedia</a>
	                            </td>
	                            <td width="150" height="auto">
	                                <a href="#" class="tdk-bersedia">Tidak Bersedia</a>
	                            </td>
	                        </tr>
	                    </tbody>
                    </table>-->
                    <!-- <p style="margin:20px 0pt 0pt;line-height:150%;text-align:justify;">Silahkan kunjungi link <a href="#" target="_blank">Pusat Bantuan</a> untuk mengetahui pertanyaan-pertanyaan yang sering diajukan. Untuk menghubungi kami, silahkan tinggalkan pesan anda <a href="#" target="_blank">disini</a>.</p> -->
                    <br>
                    <p>Terima Kasih</p>
                    <p><strong>Managing Editor ('.$namaEditor.')</strong>
                      </p>
                </td>
            </tr>
            <tr>
                <td>
                    </td></tr><tr>
                <td>
                    <table align="center" width="700">
                        <tbody><tr>
                            <td>
                                <table align="center" width="300" border="0">
                                    <tbody><tr>
                                        <td>
                                            <table border="0" align="center" style="padding-top:5%">
                                                <tbody><tr>
                                                    <td width="60" height="35">
                                                        <a href="https://www.facebook.com/pages/LIPI-Press/597085693751515?fref=nf" title="LIPI Press" target="_blank"><img src="https://ci3.googleusercontent.com/proxy/Nm0lu0UTuIJF65grVFF-ft8OFw0mZMot6D-QLRCxbDED2wk5md-O1GjF4ddQLSByQkv6q_CvsQ9Fjl3v2y_zyXizW-shyg4GqiNFdY90PGdJW4SvhEAD7OWdw_y11Wpkh_oP-vjkKg71sw-CVsfKTZnK0OfHOCvw2rxjcCilJDWZJjGv9sczwTE=s0-d-e1-ft#http://static.cdn.responsys.net/i5/responsysimages/lazada/contentlibrary/!footer700_2/footer-promo-sg/images/fb.jpg" width="36" height="36" alt="Facebook Funbizz Indonesia" class="CToWUd"></a>
                                                    </td>
                                                    <td width="60" height="35">
                                                        <a href="https://plus.google.com/106583475677034516008/about" title="LIPI Press" target="_blank"><img src="https://ci6.googleusercontent.com/proxy/fJLjQUHPGAenLxcpaqOZnNvyGA7N7x2prlTIlV_fZ8PsJQvJvXGo9R3lb3AXFqeZgKnsFavOWw2LFBzy4L5xYBVWjukrue6_J3yw-uadGP1pYIg8dxdgC7kOKzsc8JQJ0r9n2KjH4ir0gKA96qbnkvy13AP8kqjx_FqhRt0mOtRBfoXXJgwdsq6_Tk62=s0-d-e1-ft#http://static.cdn.responsys.net/i5/responsysimages/lazada/contentlibrary/!footer700_2/footer-promo-sg/images/google.jpg" width="36" height="36" alt="Google+ Funbizz Indonesia" class="CToWUd"></a>
                                                    </td>
                                                    <td width="60" height="35" style="padding:0px;margin:0px">
                                                        <a href="https://twitter.com/lipi_press" title="LIPI Press" target="_blank"><img src="https://ci6.googleusercontent.com/proxy/wBsYM28D2P-2dDebdSIuSsHPxNu3YDU1bgCNwIak7nJrd5Fah4q46Qbgp8udrXve70C4lekLnvHwI4qr0X2W8r2rXYVXd0VCRnPjctEjuy8ndKu-S7XbgS_n33_Z6GC_iqEQZZgSpuLkFEHbZpPTxWeh4-4F1iC8The3MJWmVT_cHYb4qACGPqG9Kp9OPw=s0-d-e1-ft#http://static.cdn.responsys.net/i5/responsysimages/lazada/contentlibrary/!footer700_2/footer-promo-sg/images/twitter.jpg" width="36" height="36" alt="Twitter Funbizz Indonesia" class="CToWUd"></a>
                                                    </td>
                                                    <td width="60" height="35" style="padding:0px;margin:0px">
                                                        <a href="https://www.youtube.com/channel/UCr1ihEI566IJib9P-JjENSA" title="LIPI Press" target="_blank"><img src="https://ci4.googleusercontent.com/proxy/r3PcUuAUgBpuLIbrV2L-IBKZ6R0hXZj89HxkHsW33rH0YCB3A_EFKE3wZe1H8Mu_ZfTc6khL-l11S9vgVQ_g_IbPFKumdfZKSi8qecEVYRfuChVHWbqsDLmx1WR3S3AY14ti3xDn3hsFCW1OjShxsD11ndN1d_Kqfzap9I_mcVdKa07bOD9w7SvQomXqHQ=s0-d-e1-ft#http://static.cdn.responsys.net/i5/responsysimages/lazada/contentlibrary/!footer700_2/footer-promo-sg/images/youtube.jpg" width="36" height="36" alt="Youtube Funbizz Indonesia" class="CToWUd"></a>
                                                    </td>
                                                </tr>
                                            </tbody></table>
                                        </td>
                                    </tr>
                                </tbody></table>
                            </td>
                        </tr>
                    </tbody></table>
                </td>
            </tr>
            <!-- <tr>
                <td width="auto" align="center" style="font-family:Calibri,sans-serif;font-size:16px">
                    <a href="#" style="color:#1a9bb8;text-decoration:none" target="_blank">Tentang Kami</a> |
                    <a href="#" style="color:#1a9bb8;text-decoration:none" target="_blank">Layanan Pelanggan</a> |
                    <a href="#" style="color:#1a9bb8;text-decoration:none" target="_blank">Kebijakan Privasi</a>
                </td>
            </tr> -->
            <tr>
                <td width="auto" height="30" style="text-align:center;font-size:10px;color:#919191">
                    <p>Jl. Gondangdia Lama (RP) Suroso, No. 39 Jakarta 10350 | Telp. (+62) 21 3140228 Fax. (+62) 21 3144591</p>
                </td>
            </tr>
            <tr>
                <td height="3" align="center" style="background-color:#004688"></td>
            </tr>
                
            
        </tbody></table>
    </td>
    <td width="50%">
    </td>
</tr>
</tbody>
</table>';
?>