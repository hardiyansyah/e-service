<?php
  session_start();
  session_destroy();
  header("location:../");
  // echo "<script>alert('Logout Berhasil'); window.location = '../index.php'</script>";
?>
